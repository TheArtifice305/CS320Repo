#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include "zemaphore.h" // Include zemaphore library

int N;                 
Zem_t *forks;          
Zem_t table;           

int algorithm_choice;  // Global variable for algorithm selection

void *philosopher(void *arg) {
    int id = *(int *)arg;
    free(arg);

    while (1) {
        printf("Philosopher %d is thinking.\n", id);
        sleep(rand() % 3 + 1); // Simulates thinking time

        printf("Philosopher %d is hungry.\n", id);

        if (algorithm_choice == 1) {
            // Algorithm 1: Pick up left fork, then right fork
            Zem_wait(&forks[id]);                // Pick up left fork
            Zem_wait(&forks[(id + 1) % N]);      // Pick up right fork
        } else if (algorithm_choice == 2) {
            // Algorithm 2: Pick up both forks if both are available
            while (1) {
                Zem_wait(&forks[id]);            // Attempt to pick up left fork
                if (pthread_mutex_trylock(&forks[(id + 1) % N].lock) == 0) { 
                    // Successfully locked the right fork
                    break;
                } else {
                    Zem_post(&forks[id]);        // Release left fork if right fork unavailable
                    usleep(1000);               // Short wait before retrying
                }
            }
        } else if (algorithm_choice == 3) {
            // Algorithm 3: Only N-1 philosophers can sit at the table
            Zem_wait(&table);                   // Sit at the table
            Zem_wait(&forks[id]);               // Pick up left fork
            Zem_wait(&forks[(id + 1) % N]);     // Pick up right fork
        }

        // Eating
        printf("Philosopher %d is eating.\n", id);
        sleep(rand() % 3 + 1); // Simulate eating time

        // Put down forks
        Zem_post(&forks[id]);                   // Release left fork
        Zem_post(&forks[(id + 1) % N]);         // Release right fork

        if (algorithm_choice == 3) {
            Zem_post(&table);                   // Leave the table
        }

        printf("Philosopher %d is done eating.\n", id);
    }
    return NULL;
}

// I just loooooove writing comments
int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <number_of_philosophers> <algorithm_choice>\n", argv[0]);
        printf("Algorithm Choices:\n");
        printf("1 - Pick left fork, then right fork (deadlock prone)\n");
        printf("2 - Pick both forks if both are available\n");
        printf("3 - Only N-1 philosophers allowed at the table\n");
        return -1;
    }

    N = atoi(argv[1]);
    algorithm_choice = atoi(argv[2]);
    if (N < 3 || N > 20) {
        printf("Number of philosophers must be between 3 and 20.\n");
        return -1;
    }
    if (algorithm_choice < 1 || algorithm_choice > 3) {
        printf("Invalid algorithm choice. Choose 1, 2, or 3.\n");
        return -1;
    }

    // Initialize semaphores
    forks = malloc(N * sizeof(Zem_t));
    for (int i = 0; i < N; ++i) {
        Zem_init(&forks[i], 1); // Each fork starts available
    }
    if (algorithm_choice == 3) {
        Zem_init(&table, N - 1); // Allow only N-1 philosophers at the table
    }

    // Create philosopher threads
    pthread_t philosophers[N];
    for (int i = 0; i < N; ++i) {
        int *id = malloc(sizeof(int));
        *id = i;
        pthread_create(&philosophers[i], NULL, philosopher, id);
    }

    // Join philosopher threads (optional: usually runs indefinitely)
    for (int i = 0; i < N; ++i) {
        pthread_join(philosophers[i], NULL);
    }

    free(forks);
    return 0;
}