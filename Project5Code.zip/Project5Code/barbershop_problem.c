#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "common_threads.h"

#define MAX_CHAIRS 5  // Number of chairs in the waiting room

// Shared resources and synchronization tools
int waitingCustomers = 0;
pthread_mutex_t mutex;
pthread_cond_t barberSleep;
pthread_cond_t customerReady;

void *barber(void *arg) {
    while (1) {
        pthread_mutex_lock(&mutex);
        // Barber sleeps if no customers are waiting
        while (waitingCustomers == 0) {
            printf("Barber is sleeping\n");
            pthread_cond_wait(&customerReady, &mutex);
        }
        // Serve a customer
        waitingCustomers--;
        printf("Barber is cutting hair, %d customers waiting\n", waitingCustomers);
        pthread_cond_signal(&barberSleep);
        pthread_mutex_unlock(&mutex);

        // Simulate hair cutting
        sleep(3);
    }
    return NULL;
}

void *customer(void *arg) {
    pthread_mutex_lock(&mutex);
    // If there is space in the waiting room
    if (waitingCustomers < MAX_CHAIRS) {
        waitingCustomers++;
        printf("Customer arrives, %d customers waiting\n", waitingCustomers);
        pthread_cond_signal(&customerReady);  // Wake up barber if needed
        // Wait for the barber to finish
        pthread_cond_wait(&barberSleep, &mutex);
    } else {
        printf("Customer leaves, no chairs available\n");
    }
    pthread_mutex_unlock(&mutex);
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <number of customers>\n", argv[0]);
        return 1;
    }
    int numCustomers = atoi(argv[1]);

    // Initialize synchronization primitives
    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&barberSleep, NULL);
    pthread_cond_init(&customerReady, NULL);

    pthread_t barberThread;
    pthread_t customerThreads[numCustomers];

    // Create the barber thread
    pthread_create(&barberThread, NULL, barber, NULL);

    // Create customer threads
    for (int i = 0; i < numCustomers; ++i) {
        pthread_create(&customerThreads[i], NULL, customer, NULL);
        // Random delay between customer arrivals
        sleep(rand() % 3);
    }

    // Wait for all customer threads to finish
    for (int i = 0; i < numCustomers; ++i) {
        pthread_join(customerThreads[i], NULL);
    }

    // Clean up and exit
    pthread_cancel(barberThread);
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&barberSleep);
    pthread_cond_destroy(&customerReady);

    return 0;
}